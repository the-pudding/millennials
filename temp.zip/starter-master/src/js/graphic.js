/* global d3 */
function resize() {}

function init() {
  console.log('Make something awesome!');
}

export default { init, resize };
